using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;

namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor
{
	/// <summary>
	/// Contract for combining an <typeparamref name="TValue"/> with a <typeparamref name="TMetadata"/> into a <typeparamref name="TValueMetadata" />.
	/// Let implementor have an <see cref="ExportAttribute"/> with <see cref="ExportAttribute.ContractType"/> = <see cref="IEnumerable{T}"/> where T is TValueMetadata.
	/// <seealso cref="ValueMetadataCompactorBase{TValue,TMetadata,TValueMetadata}"/>
	/// </summary>
	/// <typeparam name="TValue">The type of value to compact</typeparam>
	/// <typeparam name="TMetadata">The type of metadata to compact</typeparam>
	/// <typeparam name="TValueMetadata">The resuting combination value-metadata</typeparam>
	/// <remarks>The implementing class also has to be decorated with an <see cref="ExportAttribute"> 
	/// with the <see cref="Type"/> parameter set to <see cref="IEnumerable{T}"/> 
	/// where the type param is <typeparamref name="TValueMetadata"/>.</remarks>
	public abstract class ValueMetadataCompactorBase<TValue, TMetadata, TValueMetadata> :
		IEnumerable<TValueMetadata>
		where TValueMetadata : TValue, TMetadata
	{
		/// <summary>
		/// Implementation creates a <typeparamref name="TValueMetadata"/> instance from the <see cref="Lazy{T,TMetadata}"/> 
		/// with T = <typeparamref name="TValue"/> and <typeparamref name="TMetadata"/>.
		/// </summary>
		/// <returns>The resulting <typeparamref name="TValueMetadata"/> instance.</returns>
		/// <remarks>The implementing class also has to be decorated with an <see cref="ExportAttribute"> 
		/// with the <see cref="Type"/> parameter set to <see cref="IEnumerable{T}"/> 
		/// where the type param is <typeparamref name="TValueMetadata"/>.</remarks>
		protected abstract TValueMetadata Compact(Lazy<TValue, TMetadata> lazyValueMetadata);

		/// <summary>
		/// <see cref="IEnumerable{T}.GetEnumerator"/>
		/// </summary>
		public IEnumerator<TValueMetadata> GetEnumerator()
		{
			var ValuesWithMetadataCopy = ValuesWithMetadata;
			var ValueMetadatasCopy = ValueMetadatas;

			foreach (var lazyWorkItem in ValuesWithMetadataCopy)
			{
				yield return Compact(lazyWorkItem);
			}

			foreach (var valueMetadata in ValueMetadatasCopy)
			{
				var copy = valueMetadata;
				yield return copy.Value;
			}
		}

		/// <summary>
		/// <see cref="IEnumerable.GetEnumerator"/>
		/// </summary>
		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		#region Imports of many Lazy<TValueMetadata> and many Lazy<TValue, TMetadata>.

		/// <summary>
		/// The current <typeparamref name="TValueMetadata"/> tasks that might be implemented direct in the application.
		/// </summary>
		[ImportMany(AllowRecomposition = true)]
		internal IEnumerable<Lazy<TValueMetadata>> ValueMetadatas { get; set; }

		/// <summary>
		/// The current <typeparamref name="TValue" /> implementations in the application that carry <typeparamref name="TMetadata"/>
		/// </summary>
		[ImportMany(AllowRecomposition = true)]
		internal IEnumerable<Lazy<TValue, TMetadata>> ValuesWithMetadata { get; set; }

		/// <summary>
		/// Create a new workable instance.
		/// </summary>
		protected ValueMetadataCompactorBase()
		{
			// Cliped for brevity
			ValueMetadatas = Enumerable.Empty<Lazy<TValueMetadata>>();
			ValuesWithMetadata = Enumerable.Empty<Lazy<TValue, TMetadata>>();
		}

		#endregion
	}
}