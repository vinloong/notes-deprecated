using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain;

namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Services
{
	[Export(typeof(IEnumerable<IWork>))]
	internal class WorkCompactor : ValueMetadataCompactorBase<IWorkItem, IWorkItemView, IWork>
	{
		protected override IWork Compact(Lazy<IWorkItem, IWorkItemView> lazyValueMetadata)
		{
			return new WorkWrapper(lazyValueMetadata);
		}

		private class WorkWrapper : IWork
		{
			private readonly Lazy<IWorkItem, IWorkItemView> lazyWorkWithMetadata;

			public WorkWrapper(Lazy<IWorkItem, IWorkItemView> lazyWorkWithMetadata)
			{
				this.lazyWorkWithMetadata = lazyWorkWithMetadata;
			}

			public bool HasWork
			{
				get { return lazyWorkWithMetadata.Value.HasWork; }
			}

			public void DoWork()
			{
				lazyWorkWithMetadata.Value.DoWork();
			}

			public int Order
			{
				get { return lazyWorkWithMetadata.Metadata.Order; }
			}

			public string Name
			{
				get { return lazyWorkWithMetadata.Metadata.Name; }
			}
		}
	}
}