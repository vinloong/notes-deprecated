using System;
using System.ComponentModel.Composition;
using MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain;

namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Services
{
	[MetadataAttribute,
	 AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
	public class WorkItemExportAttribute : ExportAttribute, IWorkItemView
	{
		public WorkItemExportAttribute(string name, int order = int.MaxValue)
			: base(typeof(IWorkItem))
		{
			Name = name;
			Order = order;
		}

		public string Name { get; private set; }
		public int Order { get; private set; }
	}
}