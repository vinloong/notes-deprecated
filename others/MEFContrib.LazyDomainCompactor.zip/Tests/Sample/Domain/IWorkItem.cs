﻿namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain
{
	public interface IWorkItem
	{
		bool HasWork { get; }
		void DoWork();
	}
}