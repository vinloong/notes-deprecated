namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain
{
	public interface IWork : IWorkItem, IWorkItemView { }
}