﻿namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain
{
	public interface IWorkItemView
	{
		string Name { get; }
		int Order { get; }
	}
}