﻿using System.ComponentModel.Composition;
using MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain;

namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Works
{
	[Export(typeof(IWork))]
	public class WorkA : IWork
	{
		public int WorkCount;
		public bool HasWorkReturn = true;

		public bool HasWork
		{
			get
			{
				return HasWorkReturn;
			}
		}

		public void DoWork()
		{
			WorkCount++;
		}

		public string Name
		{
			get { return "Work A"; }
		}

		public int Order
		{
			get { return 42; }
		}
	}
}