using MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain;
using MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Services;

namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Works
{
	[WorkItemExport("Work item A")]
	public class WorkItemA : IWorkItem
	{
		public int WorkCount;
		public bool HasWorkReturn = true;

		public bool HasWork
		{
			get
			{
				return HasWorkReturn;
			}
		}

		public void DoWork()
		{
			WorkCount++;
		}
	}
}