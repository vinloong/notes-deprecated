using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests.Sample
{
	[TestClass]
	public class WorkCompactorTests
	{
		/// <summary>
		/// NOT ImportManyAttribute:
		/// The <see cref="WorkCompactor"/> creates and combines instances of IWork from implementations of IWorkItem with the metadata IWorkItemView.
		/// (It also adds any exported implementations of IWork.)
		/// 
		/// This code only cares about an IEnumerable{IWork} and knows nothing else.
		/// Somewhere else there is an implementation of the compactor and an <see cref="ExportAttribute"/> of all of the IWork for us to <see cref="ImportAttribute"/> here.
		/// </summary>
		[Import]
		public IEnumerable<IWork> Works { get; set; }

		[TestMethod]
		public void Import()
		{
			// Arrange
			var catalog = new AssemblyCatalog(typeof(WorkCompactorTests).Assembly);
			var container = new CompositionContainer(catalog);

			// Act - import all of our IWork
			container.SatisfyImportsOnce(this);

			Assert.AreEqual(3, Works.Count());

			var work = Works.Where(w => w.Name == "Work item A").Single();
			Assert.AreEqual(int.MaxValue, work.Order);

			work = Works.Where(w => w.Name == "Work item B").Single();
			Assert.AreEqual(2, work.Order);

			work = Works.Where(w => w.Name == "Work A").Single();
			Assert.AreEqual(42, work.Order);
		}

		/// <summary>
		/// This is the old way of doing the import many. We still do it but we hide that code and all the lazyness away from the developers.
		/// </summary>
		[ImportMany]
		public IEnumerable<Lazy<IWorkItem, IWorkItemView>> OldSchoolWorkItems { get; set; }

		[TestMethod]
		public void Import_old_school_style()
		{
			// Arrange
			var catalog = new AssemblyCatalog(typeof(WorkCompactorTests).Assembly);
			var container = new CompositionContainer(catalog);

			// Act - import all of our IWork
			container.SatisfyImportsOnce(this);

			Assert.AreEqual(2, OldSchoolWorkItems.Count());

			var workItem = OldSchoolWorkItems.Where(w => w.Metadata.Name == "Work item A").Single();
			Assert.AreEqual(int.MaxValue, workItem.Metadata.Order);

			workItem = OldSchoolWorkItems.Where(w => w.Metadata.Name == "Work item B").Single();
			Assert.AreEqual(2, workItem.Metadata.Order);
		}

		/// <summary>
		/// The third option just to show what it looks like to import the instances direct. The implementation of <see cref="WorkCompactor"/> combines this result
		/// with the result (<see cref="OldSchoolWorkItems"/>) above.
		/// </summary>
		[ImportMany]
		public IEnumerable<Lazy<IWork>> OldSchoolWorks { get; set; }

		[TestMethod]
		public void Import_old_school_style2()
		{
			// Arrange
			var catalog = new AssemblyCatalog(typeof(WorkCompactorTests).Assembly);
			var container = new CompositionContainer(catalog);

			// Act - import all of our IWork
			container.SatisfyImportsOnce(this);

			Assert.AreEqual(1, OldSchoolWorks.Count());

			var work = OldSchoolWorks.Where(w => w.Value.Name == "Work A").Single();
			Assert.AreEqual(42, work.Value.Order);
		}
	}
}