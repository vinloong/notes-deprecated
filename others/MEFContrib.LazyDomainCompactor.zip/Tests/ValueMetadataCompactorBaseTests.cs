using System;
using System.Linq;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;

/*
 * Note: This is just the unit tests for the base implementation of the contract.
 *       For a better view of what this code is all about <see cref="Sample.WorkCompactorTests"/>.
 *       ;~)
 */

namespace MEFContrib.ComponentModel.Composition.LazyDomainCompactor.Tests
{
	interface IFoo { }
	interface IFooView { }
	interface IFooWithView : IFoo, IFooView { }

	class Foo : IFoo { }
	class FooView : IFooView { }
	class FooWithView : IFooWithView
	{
		public FooWithView() { }

		public FooWithView(IFoo foo, IFooView view)
		{
			Foo = foo;
			View = view;
		}

		public IFoo Foo { get; set; }
		public IFooView View { get; set; }
	}

	/// <summary>
	/// This is the test implementation of the <see cref="ValueMetadataCompactorBase"/> that we use in the tests below.
	/// </summary>
	class ValueMetadataCompactorTester : ValueMetadataCompactorBase<IFoo, IFooView, IFooWithView>
	{
		public int CompactCalls;

		protected override IFooWithView Compact(Lazy<IFoo, IFooView> lazyValueMetadata)
		{
			CompactCalls++;
			return new FooWithView(lazyValueMetadata.Value, lazyValueMetadata.Metadata);
		}

		public IFooWithView CallCompact(Lazy<IFoo, IFooView> lazyValueMetadata)
		{
			return Compact(lazyValueMetadata);
		}
	}

	[TestClass]
	public class ValueMetadataCompactorBaseTests
	{
		ValueMetadataCompactorTester ValueMetadataCompactor;

		[TestInitialize]
		public void Create_ValueMetadataProvider()
		{
			ValueMetadataCompactor = new ValueMetadataCompactorTester();
		}

		[TestMethod]
		public void Default_is_zero_values()
		{
			Assert.AreEqual(0, ValueMetadataCompactor.Count());
			Assert.AreEqual(0, ValueMetadataCompactor.CompactCalls);
		}

		[TestMethod]
		public void Setting_one_ValueMetadata_returns_one()
		{
			var foo = new FooWithView();
			var lazyFoo = new Lazy<IFooWithView>(() => foo);
			ValueMetadataCompactor.ValueMetadatas = new[] { lazyFoo };

			// Act
			int noOfItems = ValueMetadataCompactor.Count();

			Assert.AreEqual(1, noOfItems);
			var result = ValueMetadataCompactor.First();
			Assert.AreSame(foo, result);
			Assert.AreEqual(0, ValueMetadataCompactor.CompactCalls);
		}

		[TestMethod]
		public void Compact_one_value()
		{
			var foo = new Foo();
			var fooView = new FooView();
			var instance = new Lazy<IFoo, IFooView>(() => foo, fooView);

			var lazy = ValueMetadataCompactor.CallCompact(instance);

			Assert.IsNotNull(lazy);
			var theFooWithView = (FooWithView)lazy;
			Assert.AreSame(foo, theFooWithView.Foo);
			Assert.AreSame(fooView, theFooWithView.View);
		}

		[TestMethod]
		public void Setting_two_ValueMetadata_returns_two()
		{
			var foo = new Lazy<IFooWithView>(() => new FooWithView());
			ValueMetadataCompactor.ValueMetadatas = new[] { foo, foo };

			// Act
			int noOfItems = ValueMetadataCompactor.Count();

			Assert.AreEqual(2, noOfItems);
		}

		[TestMethod]
		public void Setting_one_LazyValueWithMetadata_returns_one()
		{
			var foo = new Lazy<IFoo, IFooView>(() => new Foo(), new FooView());
			ValueMetadataCompactor.ValuesWithMetadata = new[] { foo };

			// Act
			int noOfItems = ValueMetadataCompactor.Count();

			Assert.AreEqual(1, noOfItems);
			Assert.AreEqual(1, ValueMetadataCompactor.CompactCalls);
		}

		[TestMethod]
		public void Setting_two_LazyValueWithMetadata_returns_two()
		{
			var foo = new Lazy<IFoo, IFooView>(() => new Foo(), new FooView());
			ValueMetadataCompactor.ValuesWithMetadata = new[] { foo, foo };

			// Act
			int noOfItems = ValueMetadataCompactor.Count();

			Assert.AreEqual(2, noOfItems);
		}

		[TestMethod]
		public void Setting_one_of_each_returns_two()
		{
			ValueMetadataCompactor.ValueMetadatas = new[]
			{
				new Lazy<IFooWithView>(() => new FooWithView())
			};
			ValueMetadataCompactor.ValuesWithMetadata = new[]
			{
				new Lazy<IFoo, IFooView>(() => new Foo(), new FooView())
			};

			// Act
			int noOfItems = ValueMetadataCompactor.Count();

			Assert.AreEqual(2, noOfItems);
			Assert.AreEqual(1, ValueMetadataCompactor.CompactCalls);
		}

		[TestMethod]
		public void IEnumerator()
		{
			// Arrange
			var lazyFooWithView = new Lazy<IFoo, IFooView>(() => new Foo(), new FooView());
			ValueMetadataCompactor.ValuesWithMetadata = new[]
			{
				lazyFooWithView, lazyFooWithView, lazyFooWithView
			};

			var lazyFooWithView2 = new Lazy<IFooWithView>(() => new FooWithView());
			ValueMetadataCompactor.ValueMetadatas = new[]
			{
				lazyFooWithView2, lazyFooWithView2, lazyFooWithView2
			};

			int i = 0;
			// Act - call to IEnumerable.GetEnumerator()
			foreach (var item in (IEnumerable)ValueMetadataCompactor)
			{
				i++;
			}

			Assert.AreEqual(6, i);
		}
	}
}