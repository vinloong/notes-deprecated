﻿using mefdemo.idapters;
using System;
using System.Collections.Generic;
using System.Composition;

namespace mefdemo.services
{
    [Export(typeof(IEnumerable<IAdapter>))]
    public class AdapterCompactor : ValueMetadataCompactorBase<IAdapterItem, IAdapterItemMetaData, IAdapter>
    {
        protected override IAdapter Compact(Lazy<IAdapterItem, IAdapterItemMetaData> lazyValueMetadata)
        {
            return new AdapterWrapper(lazyValueMetadata);
        }

        private class AdapterWrapper : IAdapter
        {
            private readonly Lazy<IAdapterItem, IAdapterItemMetaData> lazyAdapterValueMetadata;

            public AdapterWrapper(Lazy<IAdapterItem, IAdapterItemMetaData> lazyValueMetadata)
            {
                this.lazyAdapterValueMetadata = lazyValueMetadata;
                
            }

            public int Protocol
            {
                get
                {
                    return lazyAdapterValueMetadata.Metadata.Protocol;
                }
            }

            public string Desc {
                get
                {
                    return lazyAdapterValueMetadata.Metadata.Desc;
                }
            }

            public void ParseResult()
            {
                lazyAdapterValueMetadata.Value.ParseResult();
            }

            public void Request()
            {
                lazyAdapterValueMetadata.Value.Request();
            }
        }

    }
}
