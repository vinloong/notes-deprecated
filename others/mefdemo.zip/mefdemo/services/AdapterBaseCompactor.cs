﻿using mefdemo.idapters;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Composition;
using System.Linq;

namespace mefdemo.services
{
    public class AdapterBaseCompactor: IEnumerable<AdapterBase>
    {
        [ImportMany]
        internal IEnumerable<Lazy<AdapterBase>> ValueMetadatas { get; set; }

        [ImportMany]
        internal IEnumerable<Lazy<IAdapterItem, AdapterItemExportAttribute>> ValuesWithMetadata { get; set; }


        protected AdapterBaseCompactor()
        {
            ValueMetadatas = Enumerable.Empty<Lazy<AdapterBase>>();
            ValuesWithMetadata = Enumerable.Empty<Lazy<IAdapterItem, AdapterItemExportAttribute>>();
        }

        public IEnumerator<AdapterBase> GetEnumerator()
        {
            var ValuesWithMetadataCopy = ValuesWithMetadata;
            var ValueMetadatasCopy = ValueMetadatas;

            foreach (var lazyWorkItem in ValuesWithMetadataCopy)
            {
                yield return Compact(lazyWorkItem);
            }

            foreach (var valueMetadata in ValueMetadatasCopy)
            {
                var copy = valueMetadata;
                yield return copy.Value;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        protected AdapterBase Compact(Lazy<IAdapterItem, AdapterItemExportAttribute> lazyValueMetadata)
        {
            return new AdapterWrapper(lazyValueMetadata);
        }


        private class AdapterWrapper : AdapterBase
        {
            private readonly Lazy<IAdapterItem, AdapterItemExportAttribute> lazyAdapterValueMetadata;


            public AdapterWrapper(Lazy<IAdapterItem, AdapterItemExportAttribute> lazyValueMetadata)
            {
                this.lazyAdapterValueMetadata = lazyValueMetadata;

            }

            public int Protocol
            {
                get
                {
                    return lazyAdapterValueMetadata.Metadata.Protocol;
                }
            }

            public string Desc
            {
                get
                {
                    return lazyAdapterValueMetadata.Metadata.Desc;
                }
            }

            public override void ParseResult()
            {
                lazyAdapterValueMetadata.Value.ParseResult();
            }

            public override void Request()
            {
                lazyAdapterValueMetadata.Value.Request();
            }
        }
    }


}
