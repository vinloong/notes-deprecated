﻿using mefdemo.idapters;
using System;
using System.Composition;

namespace mefdemo.plugins
{
    [Export(typeof(AdapterBase))]
    public class AdapterC : AdapterBase
    {
        public override void ParseResult()
        {
            Console.WriteLine(".... parsed test C ... ...");
        }

        public override void Request()
        {
            Console.WriteLine(".... request test C ... ...");
        }

        public int Protocol
        {
            get
            {
                return 3000;
            }
        }

        public string Desc
        {
            get
            {
                return "Test C";
            }
        }

    }
}
