﻿
using mefdemo.idapters;
using System;
using System.Composition;

namespace mefdemo.plugins
{
    [Export(typeof(IAdapterItem))]
    [AdapterItemExport( Protocol = 2000,Desc = "Test B")]
    class AdapterB:IAdapterItem
    {
        public void ParseResult()
        {
            Console.WriteLine(".... parsed test B ... ...");
        }

        public void Request()
        {
            Console.WriteLine(".... request test B ... ...");
        }
    }
}
