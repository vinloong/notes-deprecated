﻿using System;
using System.Composition;
using mefdemo.idapters;

namespace mefdemo.plugins
{
    //[AdapterItemExport(10000, "Test A")]
    [Export(typeof(IAdapterItem))]
    [AdapterItemExport( Protocol = 10000,Desc =  "Test A")]
    class AdapterA : IAdapterItem
    {
        public void ParseResult()
        {
            Console.WriteLine(".... parsed test A ... ...");
        }

        public void Request()
        {
            Console.WriteLine(".... request test A ... ...");
        }
    }
}
