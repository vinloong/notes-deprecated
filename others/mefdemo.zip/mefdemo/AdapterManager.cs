﻿using System.Collections.Generic;
using System;
using System.Linq;
using System.Composition.Hosting;
using System.Reflection;
using mefdemo.idapters;
using System.Composition;


namespace mefdemo
{
    class AdapterManager
    {
        public IEnumerable<AdapterBase> Adapters { get; set; }

        [ImportMany]
        public IEnumerable<Lazy<IAdapterItem, AdapterItemExportAttribute>> AdapterItems { get; set; }




        public void Initialize()
        {
            ContainerConfiguration cc = new ContainerConfiguration()
                .WithAssembly(Assembly.GetExecutingAssembly());

            using (var container = cc.CreateContainer())
            {
                container.SatisfyImports(this);
            }

            Console.WriteLine(" AdapterItems count: {0} ", AdapterItems == null ? 0 : AdapterItems.Count()
         );

            //Console.WriteLine("Adapter count: {0} , AdapterItems count: {1} ",
            //   Adapters == null ? 0 : Adapters.Count(),
            //   AdapterItems == null ? 0 : AdapterItems.Count()
            //    );

            //foreach(var adapter in Adapters)
            //{
            //    Console.WriteLine("this protocol : code={0} ,  desc: {1}",adapter.Protocol,adapter.Desc);
            //    adapter.Request();
            //    adapter.ParseResult();
            //}

        }


    }
}
