﻿

namespace mefdemo.idapters
{
    public interface IAdapterItemMetaData
    {
        int Protocol { get; }

        string Desc { get; }

    }
}
