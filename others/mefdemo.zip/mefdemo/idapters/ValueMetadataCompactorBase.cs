﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Composition;
using System.Linq;

namespace mefdemo.idapters
{
    public abstract class ValueMetadataCompactorBase<TValue, TMetadata, TValueMetadata> :
		IEnumerable<TValueMetadata>
		where TValueMetadata : TValue, TMetadata
	{

		protected abstract TValueMetadata Compact(Lazy<TValue, TMetadata> lazyValueMetadata);

		public IEnumerator<TValueMetadata> GetEnumerator()
		{
			var ValuesWithMetadataCopy = ValuesWithMetadata;
			var ValueMetadatasCopy = ValueMetadatas;

			foreach (var lazyWorkItem in ValuesWithMetadataCopy)
			{
				yield return Compact(lazyWorkItem);
			}

			foreach (var valueMetadata in ValueMetadatasCopy)
			{
				var copy = valueMetadata;
				yield return copy.Value;
			}
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}


		[ImportMany]
		internal IEnumerable<Lazy<TValueMetadata>> ValueMetadatas { get; set; }

		[ImportMany]
		internal IEnumerable<Lazy<TValue, TMetadata>> ValuesWithMetadata { get; set; }
	            	
		protected ValueMetadataCompactorBase()
		{
			ValueMetadatas = Enumerable.Empty<Lazy<TValueMetadata>>();
			ValuesWithMetadata = Enumerable.Empty<Lazy<TValue, TMetadata>>();
		}

	}
}
