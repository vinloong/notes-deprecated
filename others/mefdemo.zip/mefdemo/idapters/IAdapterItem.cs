﻿

namespace mefdemo.idapters
{
    public interface IAdapterItem
    {
        void Request();

        void ParseResult();

    }
}
