﻿using mefdemo.services;

namespace mefdemo.idapters
{
    public interface IAdapter : IAdapterItem, IAdapterItemMetaData { }

    public abstract class AdapterBase : AdapterItemExportAttribute, IAdapterItem
    {
        public abstract void ParseResult();
        public abstract void Request();
    }
}
