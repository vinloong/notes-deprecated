﻿using mefdemo.services;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Composition;
using System.Linq;

namespace mefdemo.idapters
{
    public abstract class AdapterMetadataCompactorBase<TValueMetadata> : IEnumerable<TValueMetadata> where TValueMetadata : AdapterItemExportAttribute, IAdapterItem
    {
		protected abstract TValueMetadata Compact(Lazy<IAdapterItem, AdapterItemExportAttribute> lazyValueMetadata);

		public IEnumerator<TValueMetadata> GetEnumerator()
		{
			var ValuesWithMetadataCopy = ValuesWithMetadata;
			var ValueMetadatasCopy = ValueMetadatas;

			foreach (var lazyWorkItem in ValuesWithMetadataCopy)
			{
				yield return Compact(lazyWorkItem);
			}

			foreach (var valueMetadata in ValueMetadatasCopy)
			{
				var copy = valueMetadata;
				yield return copy.Value;
			}
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		[ImportMany]
		internal IEnumerable<Lazy<TValueMetadata>> ValueMetadatas { get; set; }

		[ImportMany]
		internal IEnumerable<Lazy<IAdapterItem, AdapterItemExportAttribute>> ValuesWithMetadata { get; set; }


		protected AdapterMetadataCompactorBase()
		{
			ValueMetadatas = Enumerable.Empty<Lazy<TValueMetadata>>();
			ValuesWithMetadata = Enumerable.Empty<Lazy<IAdapterItem, AdapterItemExportAttribute>>();
		}

	}


}
