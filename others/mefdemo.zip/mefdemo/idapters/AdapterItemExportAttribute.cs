﻿using System;
using System.Composition;

namespace mefdemo.idapters
{
    [MetadataAttribute]
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class AdapterItemExportAttribute : Attribute // ExportAttribute//, IAdapterItemMetaData
    {
        public int Protocol { get; set; }

        public string Desc { get; set; }
    }
}
