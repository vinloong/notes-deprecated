﻿
using System;

namespace mefdemo
{

    class Program
    {


        static void Main(string[] args)
        {

            AdapterManager adapterManager = new AdapterManager();
            adapterManager.Initialize();
            Console.ReadLine();


        }
    }
}
